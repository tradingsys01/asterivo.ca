exports.id=346,exports.ids=[346],exports.modules={10152:(a,b,c)=>{Promise.resolve().then(c.bind(c,38493))},17613:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,25227,23)),Promise.resolve().then(c.t.bind(c,86346,23)),Promise.resolve().then(c.t.bind(c,27924,23)),Promise.resolve().then(c.t.bind(c,40099,23)),Promise.resolve().then(c.t.bind(c,38243,23)),Promise.resolve().then(c.t.bind(c,28827,23)),Promise.resolve().then(c.t.bind(c,62763,23)),Promise.resolve().then(c.t.bind(c,97173,23)),Promise.resolve().then(c.bind(c,25587))},23304:(a,b,c)=>{Promise.resolve().then(c.bind(c,86035))},38493:(a,b,c)=>{"use strict";c.d(b,{default:()=>f});var d=c(60687),e=c(43210);function f(){let[a,b]=(0,e.useState)(!1),[c,f]=(0,e.useState)([{id:"1",text:"Hi! I'm Asterivo's AI assistant, powered by Claude. I can have natural conversations and provide detailed help about our services. What would you like to know about AI automation or our Website in a Day offering?",isBot:!0,timestamp:new Date}]),[g,h]=(0,e.useState)(!0),[i,j]=(0,e.useState)(""),[k,l]=(0,e.useState)(!1),m=(0,e.useRef)(null),n=async(a,b)=>{try{let c=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:a,conversationHistory:b})});if(!c.ok)throw Error(`HTTP error! status: ${c.status}`);return(await c.json()).response||o(a,b)}catch(c){return console.error("API call failed:",c),o(a,b)}},o=(a,b)=>{let c=a.toLowerCase();return c.includes("speak to someone")||c.includes("talk to human")||c.includes("real person")||c.includes("sales team")||c.includes("expert")||c.includes("specialist")?`Absolutely! Our team would love to speak with you directly.

🎯 **Connect with our experts:**
• **Best option:** Fill out our contact form at /contact
• **Response time:** Within 2 business hours  
• **What to expect:** Free consultation about your specific needs
• **Who you'll speak with:** Our AI automation specialists

Just mention you came from the AI chat and we'll prioritize your request!

Is there anything I can help you with in the meantime?`:c.includes("hello")||c.includes("hi")||c.includes("hey")?"Hi! I'm Asterivo's AI assistant. I can help you learn about our AI automation services and Website in a Day offering. How can I assist you today?":c.includes("service")||c.includes("what do you do")||c.includes("offerings")?`We offer several services to help small businesses save time and grow:

**Website in a Day:**
• Launch Day ($997) - 3 pages + AI chatbot, delivered in 8 hours
• Business Day ($2,497) - 5 pages + AI + automation features  
• AI-Powered Day ($4,997) - 10 pages + advanced AI integration

**AI Automation (Monthly):**
• Starter ($497/month) - Basic workflow automation
• Growth ($997/month) - Advanced automation + integrations
• Scale ($1,997/month) - Enterprise-level automation

Which service interests you most? I can provide more details about any of these!`:c.includes("price")||c.includes("cost")||c.includes("$")||c.includes("pricing")?`Here's our pricing structure:

**Website in a Day:**
• Launch Day: $997 (3 pages + AI chatbot)
• Business Day: $2,497 (5 pages + AI + automation)
• AI-Powered Day: $4,997 (10 pages + advanced AI)

**AI Automation (Monthly):**
• Starter: $497/month (basic automation)
• Growth: $997/month (advanced features)
• Scale: $1,997/month (enterprise-level)

All our clients typically see ROI within 30 days. Would you like details about any specific package?`:c.includes("website")||c.includes("web")||c.includes("day")?`Our Website in a Day service gets your business online FAST! Here's how it works:

✅ **8-Hour Delivery Promise** - Your website goes live the same business day
✅ **Professional Design** - Custom-built, not templates
✅ **AI Integration** - Smart chatbots and automation included
✅ **Mobile Optimized** - Looks perfect on all devices

**Three Options:**
• Launch Day ($997) - Perfect for getting started quickly
• Business Day ($2,497) - Includes automation features
• AI-Powered Day ($4,997) - Full AI integration

Want to see how this could work for your business?`:c.includes("automat")||c.includes("ai")||c.includes("process")||c.includes("save time")?`Our AI automation helps you save 10+ hours per week by automating:

🤖 **Lead Management** - Instant response and qualification
📧 **Email Marketing** - Automated sequences and follow-ups
📊 **Data Entry & Reporting** - No more manual input
💬 **Customer Support** - AI-powered response system
📱 **Social Media** - Automated posting and engagement
💰 **Invoicing** - Auto-generate quotes and invoices

Most clients see ROI within 30 days. What processes are taking up most of your time right now?`:c.includes("contact")||c.includes("get started")||c.includes("call")||c.includes("email")||c.includes("consultation")?`Great! I'd love to help you get started. Here's the best way to connect:

🎯 **Free Consultation** - Visit /contact to get started
⚡ **Quick Response** - We respond within 2 business hours
💡 **Custom Solution** - We'll discuss your specific needs
📈 **ROI Planning** - See exactly how we'll save you time

What type of service interests you most? I can help guide you to the right solution before you reach out!`:c.includes("roi")||c.includes("results")||c.includes("save")||c.includes("worth it")?`Our clients typically see amazing results:

📈 **ROI Timeline:** 30 days average
⏱️ **Time Savings:** 10+ hours per week
💰 **Cost Reduction:** 50-70% vs hiring employees
🚀 **Growth:** 3x faster lead response times

**Real Examples:**
• Law firm automated client intake - saved 15 hours/week
• Restaurant automated reservations - 40% more bookings
• Consultant automated proposals - closed deals 2x faster

What's your biggest time-consuming task right now? I can show you exactly how we'd automate it!`:c.includes("how long")||c.includes("timeline")||c.includes("when")||c.includes("time")?`Here are our implementation timelines:

⚡ **Website in a Day:** 8 hours (same business day!)
🤖 **AI Automation Setup:** 1-2 weeks 
📚 **Team Training:** 2-4 hours
📊 **ROI Achieved:** Within 30 days typically

**Today's Timeline Example:**
• 9 AM: Kickoff call and requirements
• 12 PM: Design approval 
• 4 PM: Content and features complete
• 5 PM: Your website is LIVE!

What's your ideal timeline for getting started?`:c.includes("vs")||c.includes("compare")||c.includes("alternative")||c.includes("better")?`Here's why businesses choose Asterivo over alternatives:

**vs Traditional Web Agencies:**
✅ 8 hours vs 8 weeks delivery
✅ $997-$4,997 vs $10,000+ costs
✅ AI-powered vs static websites

**vs DIY Solutions:**
✅ Professional vs amateur look
✅ AI integration vs basic templates  
✅ Ongoing support vs figure-it-out-yourself

**vs Enterprise Solutions:**
✅ Small business pricing vs enterprise costs
✅ Personal service vs account managers
✅ Quick implementation vs months of setup

What specific comparison were you thinking about?`:c.includes("custom")||c.includes("specific")||c.includes("my business")||c.includes("industry")||c.includes("unique")||c.includes("tailored")||c.includes("integration")||c.includes("api")||c.includes("complex")?`That's a great question that would benefit from a personalized discussion! 

While I can provide general information about our services, your specific situation sounds like it needs a custom approach. 

🎯 **Let's connect you with our team:**
• Visit /contact for our contact form
• We'll respond within 2 business hours
• Get a free consultation tailored to your needs
• Discuss custom solutions for your specific situation

In the meantime, is there anything general about our Website in a Day or AI Automation services I can help explain?`:`I'd be happy to help! While I can provide information about our main services, your question might benefit from speaking directly with our team for the most accurate answer.

**Quick Service Overview:**
• **Website in a Day** ($997-$4,997) - Professional websites in 8 hours
• **AI Automation** ($497-$1,997/month) - Save 10+ hours per week

**For detailed questions like yours:**
🎯 **Contact our team at /contact** - We respond within 2 business hours and can give you specific answers tailored to your situation.

Is there anything general about our services I can help explain while you're here?`},p=async a=>{let b=a||i;if(!b.trim())return;let d={id:Date.now().toString(),text:b,isBot:!1,timestamp:new Date};f(a=>[...a,d]),j(""),l(!0),h(!1);let e=await n(b,c);setTimeout(()=>{let a={id:(Date.now()+1).toString(),text:e,isBot:!0,timestamp:new Date};f(b=>[...b,a]),l(!1)},500)};return(0,d.jsxs)(d.Fragment,{children:[!a&&(0,d.jsxs)("button",{onClick:()=>b(!0),className:"fixed bottom-6 right-6 z-[9999] bg-blue-600 hover:bg-blue-700 text-white p-4 rounded-full shadow-2xl transition-all duration-300 hover:scale-110",style:{position:"fixed",bottom:"24px",right:"24px",zIndex:9999,width:"64px",height:"64px",backgroundColor:"#2563eb",borderRadius:"50%",border:"none",cursor:"pointer",boxShadow:"0 25px 50px -12px rgba(0, 0, 0, 0.25)"},"aria-label":"Open AI Chat",children:[(0,d.jsx)("svg",{className:"w-6 h-6",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,d.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"})}),(0,d.jsx)("div",{className:"absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full animate-pulse"}),(0,d.jsx)("div",{className:"absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full animate-ping"})]}),a&&(0,d.jsxs)("div",{className:"fixed bottom-6 right-6 z-[9999] w-96 h-[500px] bg-white dark:bg-slate-800 rounded-lg shadow-2xl border border-slate-200 dark:border-slate-700 flex flex-col",children:[(0,d.jsxs)("div",{className:"flex items-center justify-between p-4 border-b border-slate-200 dark:border-slate-700 bg-blue-600 text-white rounded-t-lg",children:[(0,d.jsxs)("div",{className:"flex items-center space-x-3",children:[(0,d.jsx)("div",{className:"w-8 h-8 bg-white/20 rounded-full flex items-center justify-center",children:(0,d.jsx)("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,d.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"})})}),(0,d.jsxs)("div",{children:[(0,d.jsx)("h3",{className:"font-semibold",children:"AI Assistant"}),(0,d.jsx)("p",{className:"text-xs opacity-90",children:"\uD83E\uDD16 Powered by Claude • Real AI conversations"})]})]}),(0,d.jsx)("button",{onClick:()=>b(!1),className:"text-white/70 hover:text-white",children:(0,d.jsx)("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,d.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M6 18L18 6M6 6l12 12"})})})]}),(0,d.jsxs)("div",{className:"flex-1 overflow-y-auto p-4 space-y-4",children:[c.map(a=>(0,d.jsx)("div",{className:`flex ${a.isBot?"justify-start":"justify-end"}`,children:(0,d.jsx)("div",{className:`max-w-[80%] p-3 rounded-lg whitespace-pre-line ${a.isBot?"bg-slate-100 dark:bg-slate-700 text-slate-900 dark:text-white":"bg-blue-600 text-white"}`,children:(0,d.jsx)("div",{dangerouslySetInnerHTML:{__html:a.text.replace(/asterivo\.ca\/contact\//g,'<a href="/contact/" class="text-blue-600 dark:text-blue-400 underline hover:text-blue-800 dark:hover:text-blue-300 font-medium" onclick="window.open(\'/contact/\', \'_blank\'); return false;">asterivo.ca/contact/</a>').replace(/\/services/g,'<a href="/services/" class="text-blue-600 dark:text-blue-400 underline hover:text-blue-800 dark:hover:text-blue-300 font-medium" onclick="window.open(\'/services/\', \'_blank\'); return false;">/services</a>').replace(/\/pricing/g,'<a href="/pricing/" class="text-blue-600 dark:text-blue-400 underline hover:text-blue-800 dark:hover:text-blue-300 font-medium" onclick="window.open(\'/pricing/\', \'_blank\'); return false;">/pricing</a>').replace(/\[([^\]]+)\]\(([^)]+)\)/g,'<a href="$2" class="text-blue-600 dark:text-blue-400 underline hover:text-blue-800 dark:hover:text-blue-300 font-medium" onclick="window.open(\'$2\', \'_blank\'); return false;">$1</a>')}})})},a.id)),k&&(0,d.jsx)("div",{className:"flex justify-start",children:(0,d.jsx)("div",{className:"bg-slate-100 dark:bg-slate-700 p-3 rounded-lg",children:(0,d.jsxs)("div",{className:"flex space-x-1",children:[(0,d.jsx)("div",{className:"w-2 h-2 bg-slate-400 rounded-full animate-bounce"}),(0,d.jsx)("div",{className:"w-2 h-2 bg-slate-400 rounded-full animate-bounce",style:{animationDelay:"0.1s"}}),(0,d.jsx)("div",{className:"w-2 h-2 bg-slate-400 rounded-full animate-bounce",style:{animationDelay:"0.2s"}})]})})}),g&&!k&&(0,d.jsx)("div",{className:"flex justify-start",children:(0,d.jsxs)("div",{className:"max-w-[80%]",children:[(0,d.jsx)("p",{className:"text-sm text-slate-500 dark:text-slate-400 mb-2",children:"Quick questions:"}),(0,d.jsx)("div",{className:"grid grid-cols-2 gap-2 mb-3",children:[{text:"Our Services",action:"services"},{text:"Website Pricing",action:"website"},{text:"AI Automation",action:"automation"},{text:"Contact Expert",action:"I have specific questions about my business needs"}].map((a,b)=>(0,d.jsx)("button",{onClick:()=>p(a.action),className:"text-xs bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-800 rounded-lg px-3 py-2 hover:bg-blue-100 dark:hover:bg-blue-900/50 transition-colors text-left",children:a.text},b))}),(0,d.jsx)("button",{onClick:()=>window.location.href="/contact",className:"w-full text-xs bg-green-600 hover:bg-green-700 text-white rounded-lg px-3 py-2 transition-colors font-medium",children:"\uD83D\uDCE7 Go to Contact Form"})]})}),(0,d.jsx)("div",{ref:m})]}),(0,d.jsx)("div",{className:"p-4 border-t border-slate-200 dark:border-slate-700",children:(0,d.jsxs)("div",{className:"flex space-x-2",children:[(0,d.jsx)("input",{type:"text",value:i,onChange:a=>j(a.target.value),onKeyPress:a=>{"Enter"===a.key&&p()},placeholder:"Ask me about our services...",className:"flex-1 px-3 py-2 border border-slate-300 dark:border-slate-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-slate-700 dark:text-white",disabled:k}),(0,d.jsx)("button",{onClick:p,disabled:!i.trim()||k,className:"bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white p-2 rounded-lg transition-colors",children:(0,d.jsx)("svg",{className:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,d.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M12 19l9 2-9-18-9 18 9-2zm0 0v-8"})})})]})})]})]})}},61135:()=>{},70440:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>e});var d=c(31658);let e=async a=>[{type:"image/x-icon",sizes:"16x16",url:(0,d.fillMetadataSegment)(".",await a.params,"favicon.ico")+""}]},86035:(a,b,c)=>{"use strict";c.d(b,{default:()=>d});let d=(0,c(61369).registerClientReference)(function(){throw Error("Attempted to call the default export of \"/home/gs/ws/asterivo.ca/src/components/AIChatbot.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/home/gs/ws/asterivo.ca/src/components/AIChatbot.tsx","default")},93645:(a,b,c)=>{Promise.resolve().then(c.t.bind(c,16133,23)),Promise.resolve().then(c.t.bind(c,16444,23)),Promise.resolve().then(c.t.bind(c,16042,23)),Promise.resolve().then(c.t.bind(c,49477,23)),Promise.resolve().then(c.t.bind(c,29345,23)),Promise.resolve().then(c.t.bind(c,12089,23)),Promise.resolve().then(c.t.bind(c,46577,23)),Promise.resolve().then(c.t.bind(c,31307,23)),Promise.resolve().then(c.t.bind(c,14817,23))},94431:(a,b,c)=>{"use strict";c.r(b),c.d(b,{default:()=>k,metadata:()=>j});var d=c(37413),e=c(2202),f=c.n(e),g=c(64988),h=c.n(g);c(61135);var i=c(86035);let j={title:"Asterivo - Cut 10+ Hours of Busy Work Every Week with Simple AI Tools",description:"We help small businesses automate repetitive tasks without the enterprise price tag. Get your free AI assessment and start saving time with proven automation solutions.",keywords:"AI automation for small business, business process automation, AI tools for small businesses, time-saving automation, repetitive task automation, AI consulting, business efficiency",authors:[{name:"Asterivo"}],creator:"Asterivo",publisher:"Asterivo",metadataBase:new URL("https://asterivo.ca"),openGraph:{title:"Asterivo - Cut 10+ Hours of Busy Work Every Week with Simple AI Tools",description:"We help small businesses automate repetitive tasks without the enterprise price tag. Start saving time with proven AI automation solutions.",url:"https://asterivo.ca",siteName:"Asterivo",type:"website",locale:"en_US"},twitter:{card:"summary_large_image",title:"Asterivo - Cut 10+ Hours of Busy Work Every Week with Simple AI Tools",description:"We help small businesses automate repetitive tasks without the enterprise price tag. Get your free AI assessment today."},robots:{index:!0,follow:!0,googleBot:{index:!0,follow:!0,"max-video-preview":-1,"max-image-preview":"large","max-snippet":-1}}};function k({children:a}){return(0,d.jsx)("html",{lang:"en",children:(0,d.jsxs)("body",{className:`${f().variable} ${h().variable} antialiased`,children:[a,(0,d.jsx)(i.default,{})]})})}}};