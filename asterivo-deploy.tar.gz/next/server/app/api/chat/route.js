(()=>{var a={};a.id=276,a.ids=[276],a.modules={261:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/app-paths")},3295:a=>{"use strict";a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},7944:(a,b,c)=>{"use strict";c.r(b),c.d(b,{handler:()=>F,patchFetch:()=>E,routeModule:()=>A,serverHooks:()=>D,workAsyncStorage:()=>B,workUnitAsyncStorage:()=>C});var d={};c.r(d),c.d(d,{POST:()=>y});var e=c(96559),f=c(48088),g=c(37719),h=c(26191),i=c(81289),j=c(261),k=c(92603),l=c(39893),m=c(14823),n=c(47220),o=c(66946),p=c(47912),q=c(99786),r=c(46143),s=c(86439),t=c(43365),u=c(61080),v=c(32190);let w=new u.Ay({apiKey:process.env.ANTHROPIC_API_KEY}),x=`You are Asterivo's AI assistant. Asterivo helps small businesses automate repetitive tasks and build professional websites quickly.

SERVICES & PRICING:
Website in a Day:
- Launch Day ($997): 3 pages + AI chatbot, built in 8 hours
- Business Day ($2,497): 5 pages + AI + automation features  
- AI-Powered Day ($4,997): 10 pages + advanced AI integration

AI Automation (Monthly):
- Starter ($497/month): Basic workflow automation
- Growth ($997/month): Advanced automation + integrations
- Scale ($1,997/month): Enterprise-level automation

KEY BENEFITS:
- Save 10+ hours per week through automation
- ROI typically seen within 30 days
- Same-day website delivery (8 hours)
- No enterprise price tags - built for small business

COMMON AUTOMATIONS:
- Lead response and qualification
- Email marketing sequences  
- Data entry and reporting
- Customer support responses
- Social media posting
- Invoice and quote generation

CONTACT: When users ask for consultations, detailed proposals, or want to schedule calls, ALWAYS direct them to the contact form at "asterivo.ca/contact/". Response time within 2 business hours.

WEBSITE LINKS: You can reference these clickable pages:
- asterivo.ca/contact/ (contact form)
- /services (services overview)  
- /pricing (pricing details)
- /website-in-a-day (Website in a Day info)

IMPORTANT INSTRUCTIONS:
- Be helpful, conversational, and focus on how Asterivo can solve their specific business problems
- Ask follow-up questions to understand their needs  
- Keep responses concise but informative
- When users want consultations, proposals, or detailed plans, direct them to asterivo.ca/contact/ immediately
- ALWAYS use "asterivo.ca/contact/" as the contact form URL (with trailing slash)
- You can mention /services, /pricing, or other pages when relevant - they will become clickable links
- Always mention "2 business hours response time" when directing to contact form
- Don't get too deep into technical details - save that for the consultation`;async function y(a){let b;try{let{message:c,conversationHistory:d}=b=await a.json();if(!c)return v.NextResponse.json({error:"Message is required"},{status:400});if(!process.env.ANTHROPIC_API_KEY||"your_claude_api_key_here"===process.env.ANTHROPIC_API_KEY){console.warn("Claude API key not configured, using fallback responses");let a=z(c,[],d||[]);return v.NextResponse.json({response:a})}let e="";d&&d.length>0&&(e=d.slice(-10).map(a=>`${a.isBot?"Assistant":"User"}: ${a.text}`).join("\n"));let f=`${x}

${e?`Recent conversation:
${e}
`:""}

Current user message: ${c}

Please respond as Asterivo's AI assistant:`,g=await w.messages.create({model:"claude-3-haiku-20240307",max_tokens:500,messages:[{role:"user",content:f}]}),h=g.content[0]?.type==="text"?g.content[0].text:"I apologize, but I encountered an issue processing your request.";return v.NextResponse.json({response:h})}catch(c){console.error("Claude API error:",c);let a=z(b?.message||"Hello",[],b?.conversationHistory||[]);return v.NextResponse.json({response:a})}}function z(a,b,c){let d=a.toLowerCase();return d.includes("speak to someone")||d.includes("talk to human")||d.includes("real person")||d.includes("sales team")||d.includes("expert")||d.includes("specialist")?`Absolutely! Our team would love to speak with you directly.

🎯 **Connect with our experts:**
• **Best option:** [Fill out our contact form](/contact)
• **Response time:** Within 2 business hours  
• **What to expect:** Free consultation about your specific needs
• **Who you'll speak with:** Our AI automation specialists

Just mention you came from the AI chat and we'll prioritize your request!

Is there anything I can help you with in the meantime?`:d.includes("hello")||d.includes("hi")||d.includes("hey")?"Hi! I'm Asterivo's AI assistant. I can help you learn about our AI automation services and Website in a Day offering. How can I assist you today?":d.includes("service")||d.includes("what do you do")||d.includes("offerings")?`We offer several services to help small businesses save time and grow:

**Website in a Day:**
• Launch Day ($997) - 3 pages + AI chatbot, delivered in 8 hours
• Business Day ($2,497) - 5 pages + AI + automation features  
• AI-Powered Day ($4,997) - 10 pages + advanced AI integration

**AI Automation (Monthly):**
• Starter ($497/month) - Basic workflow automation
• Growth ($997/month) - Advanced automation + integrations
• Scale ($1,997/month) - Enterprise-level automation

Which service interests you most? I can provide more details about any of these!`:d.includes("price")||d.includes("cost")||d.includes("$")||d.includes("pricing")?`Here's our pricing structure:

**Website in a Day:**
• Launch Day: $997 (3 pages + AI chatbot)
• Business Day: $2,497 (5 pages + AI + automation)
• AI-Powered Day: $4,997 (10 pages + advanced AI)

**AI Automation (Monthly):**
• Starter: $497/month (basic automation)
• Growth: $997/month (advanced features)
• Scale: $1,997/month (enterprise-level)

All our clients typically see ROI within 30 days. Would you like details about any specific package?`:d.includes("website")||d.includes("web")||d.includes("day")?`Our Website in a Day service gets your business online FAST! Here's how it works:

✅ **8-Hour Delivery Promise** - Your website goes live the same business day
✅ **Professional Design** - Custom-built, not templates
✅ **AI Integration** - Smart chatbots and automation included
✅ **Mobile Optimized** - Looks perfect on all devices

**Three Options:**
• Launch Day ($997) - Perfect for getting started quickly
• Business Day ($2,497) - Includes automation features
• AI-Powered Day ($4,997) - Full AI integration

Want to see how this could work for your business?`:d.includes("automat")||d.includes("ai")||d.includes("process")||d.includes("save time")?`Our AI automation helps you save 10+ hours per week by automating:

🤖 **Lead Management** - Instant response and qualification
📧 **Email Marketing** - Automated sequences and follow-ups
📊 **Data Entry & Reporting** - No more manual input
💬 **Customer Support** - AI-powered response system
📱 **Social Media** - Automated posting and engagement
💰 **Invoicing** - Auto-generate quotes and invoices

Most clients see ROI within 30 days. What processes are taking up most of your time right now?`:d.includes("contact")||d.includes("get started")||d.includes("call")||d.includes("email")||d.includes("consultation")?`Great! I'd love to help you get started. Here's the best way to connect:

🎯 **Free Consultation** - [Fill out our contact form here](/contact)
⚡ **Quick Response** - We respond within 2 business hours
💡 **Custom Solution** - We'll discuss your specific needs
📈 **ROI Planning** - See exactly how we'll save you time

What type of service interests you most? I can help guide you to the right solution before you reach out!`:d.includes("roi")||d.includes("results")||d.includes("save")||d.includes("worth it")?`Our clients typically see amazing results:

📈 **ROI Timeline:** 30 days average
⏱️ **Time Savings:** 10+ hours per week
💰 **Cost Reduction:** 50-70% vs hiring employees
🚀 **Growth:** 3x faster lead response times

**Real Examples:**
• Law firm automated client intake - saved 15 hours/week
• Restaurant automated reservations - 40% more bookings
• Consultant automated proposals - closed deals 2x faster

What's your biggest time-consuming task right now? I can show you exactly how we'd automate it!`:d.includes("how long")||d.includes("timeline")||d.includes("when")||d.includes("time")?`Here are our implementation timelines:

⚡ **Website in a Day:** 8 hours (same business day!)
🤖 **AI Automation Setup:** 1-2 weeks 
📚 **Team Training:** 2-4 hours
📊 **ROI Achieved:** Within 30 days typically

**Today's Timeline Example:**
• 9 AM: Kickoff call and requirements
• 12 PM: Design approval 
• 4 PM: Content and features complete
• 5 PM: Your website is LIVE!

What's your ideal timeline for getting started?`:d.includes("vs")||d.includes("compare")||d.includes("alternative")||d.includes("better")?`Here's why businesses choose Asterivo over alternatives:

**vs Traditional Web Agencies:**
✅ 8 hours vs 8 weeks delivery
✅ $997-$4,997 vs $10,000+ costs
✅ AI-powered vs static websites

**vs DIY Solutions:**
✅ Professional vs amateur look
✅ AI integration vs basic templates  
✅ Ongoing support vs figure-it-out-yourself

**vs Enterprise Solutions:**
✅ Small business pricing vs enterprise costs
✅ Personal service vs account managers
✅ Quick implementation vs months of setup

What specific comparison were you thinking about?`:d.includes("custom")||d.includes("specific")||d.includes("my business")||d.includes("industry")||d.includes("unique")||d.includes("tailored")||d.includes("integration")||d.includes("api")||d.includes("complex")?`That's a great question that would benefit from a personalized discussion! 

While I can provide general information about our services, your specific situation sounds like it needs a custom approach. 

🎯 **Let's connect you with our team:**
• [Fill out our contact form here](/contact)
• We'll respond within 2 business hours
• Get a free consultation tailored to your needs
• Discuss custom solutions for your specific situation

In the meantime, is there anything general about our Website in a Day or AI Automation services I can help explain?`:`I'd be happy to help! While I can provide information about our main services, your question might benefit from speaking directly with our team for the most accurate answer.

**Quick Service Overview:**
• **Website in a Day** ($997-$4,997) - Professional websites in 8 hours
• **AI Automation** ($497-$1,997/month) - Save 10+ hours per week

**For detailed questions like yours:**
🎯 **[Contact our team here](/contact)** - We respond within 2 business hours and can give you specific answers tailored to your situation.

Is there anything general about our services I can help explain while you're here?`}let A=new e.AppRouteRouteModule({definition:{kind:f.RouteKind.APP_ROUTE,page:"/api/chat/route",pathname:"/api/chat",filename:"route",bundlePath:"app/api/chat/route"},distDir:".next",projectDir:"",resolvedPagePath:"/home/gs/ws/asterivo.ca/src/app/api/chat/route.ts",nextConfigOutput:"",userland:d}),{workAsyncStorage:B,workUnitAsyncStorage:C,serverHooks:D}=A;function E(){return(0,g.patchFetch)({workAsyncStorage:B,workUnitAsyncStorage:C})}async function F(a,b,c){var d;let e="/api/chat/route";"/index"===e&&(e="/");let g=await A.prepare(a,b,{srcPage:e,multiZoneDraftMode:"false"});if(!g)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:u,params:v,nextConfig:w,isDraftMode:x,prerenderManifest:y,routerServerContext:z,isOnDemandRevalidate:B,revalidateOnlyGenerated:C,resolvedPathname:D}=g,E=(0,j.normalizeAppPath)(e),F=!!(y.dynamicRoutes[E]||y.routes[D]);if(F&&!x){let a=!!y.routes[D],b=y.dynamicRoutes[E];if(b&&!1===b.fallback&&!a)throw new s.NoFallbackError}let G=null;!F||A.isDev||x||(G="/index"===(G=D)?"/":G);let H=!0===A.isDev||!F,I=F&&!H,J=a.method||"GET",K=(0,i.getTracer)(),L=K.getActiveScopeSpan(),M={params:v,prerenderManifest:y,renderOpts:{experimental:{dynamicIO:!!w.experimental.dynamicIO,authInterrupts:!!w.experimental.authInterrupts},supportsDynamicResponse:H,incrementalCache:(0,h.getRequestMeta)(a,"incrementalCache"),cacheLifeProfiles:null==(d=w.experimental)?void 0:d.cacheLife,isRevalidate:I,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0,onInstrumentationRequestError:(b,c,d)=>A.onRequestError(a,b,d,z)},sharedContext:{buildId:u}},N=new k.NodeNextRequest(a),O=new k.NodeNextResponse(b),P=l.NextRequestAdapter.fromNodeNextRequest(N,(0,l.signalFromNodeResponse)(b));try{let d=async c=>A.handle(P,M).finally(()=>{if(!c)return;c.setAttributes({"http.status_code":b.statusCode,"next.rsc":!1});let d=K.getRootSpanAttributes();if(!d)return;if(d.get("next.span_type")!==m.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${d.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=d.get("next.route");if(e){let a=`${J} ${e}`;c.setAttributes({"next.route":e,"http.route":e,"next.span_name":a}),c.updateName(a)}else c.updateName(`${J} ${a.url}`)}),g=async g=>{var i,j;let k=async({previousCacheEntry:f})=>{try{if(!(0,h.getRequestMeta)(a,"minimalMode")&&B&&C&&!f)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let e=await d(g);a.fetchMetrics=M.renderOpts.fetchMetrics;let i=M.renderOpts.pendingWaitUntil;i&&c.waitUntil&&(c.waitUntil(i),i=void 0);let j=M.renderOpts.collectedTags;if(!F)return await (0,o.I)(N,O,e,M.renderOpts.pendingWaitUntil),null;{let a=await e.blob(),b=(0,p.toNodeOutgoingHttpHeaders)(e.headers);j&&(b[r.NEXT_CACHE_TAGS_HEADER]=j),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==M.renderOpts.collectedRevalidate&&!(M.renderOpts.collectedRevalidate>=r.INFINITE_CACHE)&&M.renderOpts.collectedRevalidate,d=void 0===M.renderOpts.collectedExpire||M.renderOpts.collectedExpire>=r.INFINITE_CACHE?void 0:M.renderOpts.collectedExpire;return{value:{kind:t.CachedRouteKind.APP_ROUTE,status:e.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:d}}}}catch(b){throw(null==f?void 0:f.isStale)&&await A.onRequestError(a,b,{routerKind:"App Router",routePath:e,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:B})},z),b}},l=await A.handleResponse({req:a,nextConfig:w,cacheKey:G,routeKind:f.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:y,isRoutePPREnabled:!1,isOnDemandRevalidate:B,revalidateOnlyGenerated:C,responseGenerator:k,waitUntil:c.waitUntil});if(!F)return null;if((null==l||null==(i=l.value)?void 0:i.kind)!==t.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(j=l.value)?void 0:j.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});(0,h.getRequestMeta)(a,"minimalMode")||b.setHeader("x-nextjs-cache",B?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),x&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let m=(0,p.fromNodeOutgoingHttpHeaders)(l.value.headers);return(0,h.getRequestMeta)(a,"minimalMode")&&F||m.delete(r.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||b.getHeader("Cache-Control")||m.get("Cache-Control")||m.set("Cache-Control",(0,q.getCacheControlHeader)(l.cacheControl)),await (0,o.I)(N,O,new Response(l.value.body,{headers:m,status:l.value.status||200})),null};L?await g(L):await K.withPropagatedContext(a.headers,()=>K.trace(m.BaseServerSpan.handleRequest,{spanName:`${J} ${a.url}`,kind:i.SpanKind.SERVER,attributes:{"http.method":J,"http.target":a.url}},g))}catch(b){if(L||b instanceof s.NoFallbackError||await A.onRequestError(a,b,{routerKind:"App Router",routePath:E,routeType:"route",revalidateReason:(0,n.c)({isRevalidate:I,isOnDemandRevalidate:B})}),F)throw b;return await (0,o.I)(N,O,new Response(null,{status:500})),null}}},10846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},29294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},44870:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},63033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},86439:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external")},96487:()=>{}};var b=require("../../../webpack-runtime.js");b.C(a);var c=b.X(0,[985,55,80],()=>b(b.s=7944));module.exports=c})();